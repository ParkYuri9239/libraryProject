package com.kh.notice.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.board.model.vo.Attachment;
import com.kh.notice.model.service.NoticeService;
import com.kh.notice.model.vo.Notice;

/**
 * Servlet implementation class NoticeTopDetailController
 */
@WebServlet("/topDetail.no")
public class NoticeTopDetailController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NoticeTopDetailController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		int bno = Integer.parseInt(request.getParameter("bno"));
		
		//게시글 1개 정보 가지고 오기
		Notice n = new NoticeService().selectNotice(bno);
		//첨부파일 1개 정보 가지고 오기 
		Attachment at = new NoticeService().selectAttachment(bno);
		
		System.out.println(bno);
		
		request.setAttribute("n", n);
		request.setAttribute("at", at);
		
		
		request.getRequestDispatcher("/views/notice/noticeDetailForm.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
