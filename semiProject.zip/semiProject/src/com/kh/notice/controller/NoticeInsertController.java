package com.kh.notice.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.kh.board.model.vo.Attachment;
import com.kh.common.MyFileRenamePolicy;
import com.kh.notice.model.service.NoticeService;
import com.kh.notice.model.vo.Notice;
import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class NoticeInsertController
 */
@WebServlet("/insert.no")
public class NoticeInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NoticeInsertController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		if (ServletFileUpload.isMultipartContent(request)) {

			int maxSize = 10 * 1024 * 1024;
			String savePath = request.getSession().getServletContext().getRealPath("/resources/notice_upfiles/");

			MultipartRequest multiRequest = new MultipartRequest(request, savePath, maxSize, "UTF-8",
					new MyFileRenamePolicy());

			String boardTitle = multiRequest.getParameter("title");
			String boardContent = multiRequest.getParameter("content");
			String boardWriter = String.valueOf((multiRequest.getParameter("userNo")));
			

			Notice n = new Notice();

			n.setBoardTitle(boardTitle);
			n.setBoardContent(boardContent);
			n.setBoardWriter(boardWriter);

			Attachment at = null;

			if (multiRequest.getOriginalFileName("upfile") != null) {

				// 첨부파일이 있는 경우
				at = new Attachment();
				at.setOriginName(multiRequest.getOriginalFileName("upfile")); // 원본명 반환
				at.setChangeName(multiRequest.getFilesystemName("upfile")); // 실제 서버에 업로드되어 있는 파일명 반환
				at.setFilePath("resources/notice_upfiles/");
			}
				
				int result = new NoticeService().insertNotice(n,at);

				if(result>0) {
					//성공시에는 가장 최신글로 등록이 될테니 게시글 목록 첫 페이지 띄워준다
					request.getSession().setAttribute("alertMsg", "공지사항 등록 성공");
					response.sendRedirect(request.getContextPath()+"/list.no?currentPage=1");
					
				}else {
					//실패시에는 업로드된 첨부파일을 가지고 있을 필요가 없기 때문에 삭제 작업을 해줘야한다.
					if(at !=null) { //첨부파일이 있을 때 (즉, db서비스 요청에 실패했는데 첨부파일이 있을때 )
						//삭제하고자 하는 파일 객체를 생성하여 delete 메소드를 호출해서 삭제한다.
						new File(savePath+at.getChangeName()).delete();
		
						
					}
						
					//실패시 에러페이지에 에러메시지와 함께 보내주기
					request.setAttribute("errorPage", "게시글 작성 실패");
					request.getRequestDispatcher("/views/common/errorPage.jsp").forward(request,response);
					
				
				}

			}

		}

	}