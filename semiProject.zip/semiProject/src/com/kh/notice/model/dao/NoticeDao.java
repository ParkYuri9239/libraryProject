package com.kh.notice.model.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.board.model.vo.Attachment;
import com.kh.common.JDBCTemplate;
import com.kh.common.model.vo.PageInfo;
import com.kh.notice.model.vo.BookCount;
import com.kh.notice.model.vo.Notice;

public class NoticeDao {

	private Properties prop = new Properties();

	public NoticeDao() {

		String filePath = NoticeDao.class.getResource("/db/sql/notice-mapper.xml").getPath();

		try {
			prop.loadFromXML(new FileInputStream(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// 공지사항 리스트 조회하기(공지 메인화면)
	public ArrayList<Notice> selectNoticeList(Connection conn, PageInfo pi) {

		ArrayList<Notice> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = prop.getProperty("selectNoticeList");

		int startRow = (pi.getCurrentPage() - 1) * pi.getBoardLimit() + 1;
		int endRow = pi.getCurrentPage() * pi.getBoardLimit();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);

			rset = pstmt.executeQuery();

			while (rset.next()) {

				list.add(new Notice(rset.getInt("BOARD_NO"),rset.getString("BOARD_TITLE"), rset.getInt("COUNT"),
						rset.getDate("CREATE_DATE"),rset.getInt("RNUM")));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		return list;

	}

	// 게시글 개수 listCount 구하기
	public int selectListCount(Connection conn) {

		int listCount = 0;
		ResultSet rset = null;

		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectListCount");

		try {
			pstmt = conn.prepareStatement(sql);
			rset = pstmt.executeQuery();

			if (rset.next()) {

				listCount = rset.getInt("COUNT");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		return listCount;
	}

	// 공지사항 작성하기 (글 + 첨부파일)
	public int insertNotice(Connection conn, Notice n) {

		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertNotice");

		try {

			// 카테고리와 작성자는 데이터를 추가할때는 NUMBER타입이기 때문에 형변환
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, n.getBoardTitle());
			pstmt.setString(2, n.getBoardContent());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(pstmt);
		}

		return result;

	}

	// 공지사항 작성하기 (글 + 첨부파일)
	public int insertAttachment(Connection conn, Attachment at) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertAttachment");

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, at.getOriginName());
			pstmt.setString(2, at.getChangeName());
			pstmt.setString(3, at.getFilePath());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);

		}

		return result;

	}

	// 조회수 증가
	public int increaseCount(Connection conn, int bno) {

		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("increaseCount");

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
	}

	// 게시글 1개 정보 조회
	public Notice selectNotice(Connection conn, int bno) {

		Notice n = null;
		ResultSet rset = null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectNotice");


		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);

			rset = pstmt.executeQuery();

			if (rset.next()) {
				n = new Notice(rset.getInt("BOARD_NO"), rset.getString("BOARD_TITLE"), rset.getString("BOARD_CONTENT"),
						rset.getString("USER_ID"), rset.getDate("CREATE_DATE"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		return n;
	}

	// 첨부파일 1개 정보 조회
	public Attachment selectAttachment(Connection conn, int bno) {

		Attachment at = null;
		ResultSet rset = null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectAttachment");

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);

			rset = pstmt.executeQuery();

			if (rset.next()) {
				at = new Attachment(rset.getInt("FILE_NO"), rset.getString("ORIGIN_NAME"),
						rset.getString("CHANGE_NAME"), rset.getString("FILE_PATH"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		return at;
	}

	// 게시글 삭제
	public int deleteNotice(Connection conn, int boardNo) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("deleteNotice");

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, boardNo);

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(pstmt);

		}

		return result;
	}

	
	//게시글 수정
	public int updateNotice(Connection conn, Notice n) {
			
		
				int result = 0;
				PreparedStatement pstmt = null;
				String sql = prop.getProperty("updateNotice");

				try {
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, n.getBoardTitle());
					pstmt.setString(2, n.getBoardContent());
					pstmt.setInt(3, n.getBoardNo());

					result = pstmt.executeUpdate();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {

					JDBCTemplate.close(pstmt);
				}
				return result;

			}

	
	//첨부파일 수정
	public int updateAttachment(Connection conn, Attachment at) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("updateAttachment");

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, at.getOriginName());
			pstmt.setString(2, at.getChangeName());
			pstmt.setString(3, at.getFilePath());
			pstmt.setInt(4, at.getFileNo());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(pstmt);
		}
		return result;

	}

	
	// 기존 게시글에 첨부파일 등록 메소드
	public int insertNewAttachment(Connection conn, Attachment at) {
		
	
				int result = 0;
				PreparedStatement pstmt = null;
				String sql = prop.getProperty("insertNewAttachment");

				try {
					pstmt = conn.prepareStatement(sql);

					pstmt.setInt(1, at.getRefBno());
					pstmt.setString(2, at.getOriginName());
					pstmt.setString(3, at.getChangeName());
					pstmt.setString(4, at.getFilePath());

					result = pstmt.executeUpdate();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {

					JDBCTemplate.close(pstmt);
				}
				return result;

			}

	
	//bookCount List 조회
	public ArrayList<BookCount> selectAjaxList(Connection conn) {
		
		ArrayList<BookCount> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = prop.getProperty("selectAjaxList");

		try {
			pstmt = conn.prepareStatement(sql);
		
			rset = pstmt.executeQuery();

			while (rset.next()) {

				list.add(new BookCount (rset.getInt("BOOK_NO"), 
						rset.getString("BOOK_TITLE"), 
						rset.getInt("COUNT"),
						rset.getDate("CREATE_DATE")));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		return list;

	}

	
	//rentCount 조회  최근30일이내 대출권수!!!!!!!
	public int rentCount(Connection conn, int cno) {
		
		
		int count = 0;
		ResultSet rset = null;
		PreparedStatement pstmt = null;
		
		String sql = prop.getProperty("rentCount");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cno);
			
			rset = pstmt.executeQuery();
			
			if (rset.next()) {
				count=rset.getInt("COUNT");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		return count;
	}

	
	
	//월별 (10월 11월 등) 대출권수 조회!!!
	public int monthCount(Connection conn, int cno, String month) {
		
		int rCount = 0;
		ResultSet rset = null;
		PreparedStatement pstmt = null;
		
		String sql = prop.getProperty("monthCount");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cno);
			pstmt.setString(2, month);
			
			rset = pstmt.executeQuery();
			
			if (rset.next()) {
				rCount=rset.getInt("COUNT");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		return rCount;
	}

	
	//topList
	public ArrayList<Notice> selectTopList(Connection conn) {

		ArrayList<Notice> list = new ArrayList<Notice>();
		ResultSet rset = null;
		PreparedStatement pstmt=null;
		
		String sql = prop.getProperty("selectTopList");
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			rset=pstmt.executeQuery();
			
			while (rset.next()) {

				list.add(new Notice 
						(rset.getInt("BOARD_NO"),
						rset.getString("BOARD_TITLE"), 
						rset.getDate("CREATE_DATE")));

			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {

			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		System.out.println(list);
		return list;

	}

}
