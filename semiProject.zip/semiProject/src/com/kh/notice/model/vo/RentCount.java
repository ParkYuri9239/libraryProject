package com.kh.notice.model.vo;

import java.sql.Date;

public class RentCount {

//	RBOOK_NO	NUMBER
//	BOOK_NO	NUMBER
//	USER_NO	NUMBER
//	RENT_DATE	DATE
//	RETURN_DATE	DATE
//	EXTENSION_DATE	NUMBER
//	STATUS	VARCHAR2(1 BYTE)

	private int rBookNo;
	private int bookNo;
	private int userNo;
	private Date rentDate;
	private Date returnDate;
	private int extensionDate;
	private String status;

	public RentCount() {

		super();
		// TODO Auto-generated constructor stub
	}

	public RentCount(int rBookNo, int bookNo, int userNo, Date rentDate, Date returnDate, int extensionDate,
			String status) {
		super();
		this.rBookNo = rBookNo;
		this.bookNo = bookNo;
		this.userNo = userNo;
		this.rentDate = rentDate;
		this.returnDate = returnDate;
		this.extensionDate = extensionDate;
		this.status = status;
	}

	public int getrBookNo() {
		return rBookNo;
	}

	public void setrBookNo(int rBookNo) {
		this.rBookNo = rBookNo;
	}

	public int getBookNo() {
		return bookNo;
	}

	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}

	public int getUserNo() {
		return userNo;
	}

	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}

	public Date getRentDate() {
		return rentDate;
	}

	public void setRentDate(Date rentDate) {
		this.rentDate = rentDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public int getExtensionDate() {
		return extensionDate;
	}

	public void setExtensionDate(int extensionDate) {
		this.extensionDate = extensionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "RentCount [rBookNo=" + rBookNo + ", bookNo=" + bookNo + ", userNo=" + userNo + ", rentDate=" + rentDate
				+ ", returnDate=" + returnDate + ", extensionDate=" + extensionDate + ", status=" + status + "]";
	}

}
