package com.kh.notice.model.vo;

public class BookClick {
	
//	CLICK_NO	NUMBER
//	BOOK_NO	NUMBER
//	CLICK	NUMBER
	
	private int clickNo;
	private int bookNo;
	private int click;
	
	
	
	public BookClick() {
		super();
	}



	public BookClick(int clickNo, int bookNo, int click) {
		super();
		this.clickNo = clickNo;
		this.bookNo = bookNo;
		this.click = click;
	}



	public int getClickNo() {
		return clickNo;
	}



	public void setClickNo(int clickNo) {
		this.clickNo = clickNo;
	}



	public int getBookNo() {
		return bookNo;
	}



	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}



	public int getClick() {
		return click;
	}



	public void setClick(int click) {
		this.click = click;
	}



	@Override
	public String toString() {
		return "BOOKCLICK [clickNo=" + clickNo + ", bookNo=" + bookNo + ", click=" + click + "]";
	}
	
	

}
