package com.kh.notice.model.vo;

import java.sql.Date;

public class BookCount {

//	BOOK_NO	NUMBER
//	BOOK_TITLE	VARCHAR2(100 BYTE)
//	COUNT	NUMBER
//	CREATE_DATE	DATE

	private int bookNo;
	private String bookTitle;
	private int count;
	private Date createDate;

	public BookCount() {
		super();
	}

	public BookCount(int bookNo, String bookTitle, int count, Date createDate) {
		super();
		this.bookNo = bookNo;
		this.bookTitle = bookTitle;
		this.count = count;
		this.createDate = createDate;
	}

	public int getBookNo() {
		return bookNo;
	}

	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	@Override
	public String toString() {
		return "BookCount [bookNo=" + bookNo + ", bookTitle=" + bookTitle + ", count=" + count + ", createDate="
				+ createDate + "]";
	}

}
