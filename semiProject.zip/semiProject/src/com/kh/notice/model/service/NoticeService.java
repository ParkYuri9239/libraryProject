package com.kh.notice.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.board.model.vo.Attachment;
import com.kh.common.JDBCTemplate;
import com.kh.common.model.vo.PageInfo;
import com.kh.notice.model.dao.NoticeDao;
import com.kh.notice.model.vo.BookCount;
import com.kh.notice.model.vo.Notice;

public class NoticeService {

	// 공지사항 리스트 조회하기(공지 메인화면)
	public ArrayList<Notice> selectNoticeList(PageInfo pi) {

		Connection conn = JDBCTemplate.getConnection();

		ArrayList<Notice> list = new NoticeDao().selectNoticeList(conn, pi);

		JDBCTemplate.close(conn);

		return list;

	}

	// 게시글 개수 listCount 구하기
	public int selectListCount() {

		Connection conn = JDBCTemplate.getConnection();

		int listCount = new NoticeDao().selectListCount(conn);

		JDBCTemplate.close(conn);

		return listCount;

	}

	// 공지사항 작성하기 (글 + 첨부파일)
	public int insertNotice(Notice n, Attachment at) {

		Connection conn = JDBCTemplate.getConnection();

		int result = new NoticeDao().insertNotice(conn, n);

		int result2 = 1;

		if (at != null) {
			result2 = new NoticeDao().insertAttachment(conn, at);

		}

		// 트랜잭션 처리
		if (result > 0 && result2 > 0) { // if((result*result2)>0){

			// 첨부파일이 없는 경우에 result2를 0으로 초기화해둔다면 게시글이 insert가 성공했을때도
			// result2는 여전히 0 이라서 rollback처리가 될 것이기 때문에
			// result2의 초기값을 1로 초기화해둔다
			JDBCTemplate.commit(conn);

		} else {

			JDBCTemplate.rollback(conn);
		}

		return result * result2; // 둘중 하나라도 실패하여 0값을 갖게 될 경우 돌려주는 값도 실패값을 돌려주기 위해 곱셈 결과 리턴

	}

	// 조회수 증가
	public int increaseCount(int bno) {

		Connection conn = JDBCTemplate.getConnection();

		int result = new NoticeDao().increaseCount(conn, bno);

		if (result > 0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);

		return result;
	}

	// 게시글 1개 정보 조회
	public Notice selectNotice(int bno) {

		Connection conn = JDBCTemplate.getConnection();

		Notice n = new NoticeDao().selectNotice(conn, bno);

		JDBCTemplate.close(conn);

		return n;
	}

	// 첨부파일 1개 정보 조회
	public Attachment selectAttachment(int bno) {

		Connection conn = JDBCTemplate.getConnection();

		Attachment at = new NoticeDao().selectAttachment(conn, bno);

		JDBCTemplate.close(conn);

		return at;
	}

	// 게시글 삭제
	public int deleteNotice(int boardNo) {

		Connection conn = JDBCTemplate.getConnection();

		int result = new NoticeDao().deleteNotice(conn, boardNo);

		if (result > 0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}

		JDBCTemplate.close(conn);

		return result;

	}

	// 게시글 수정
	public int updateNotice(Notice n, Attachment at) {

		Connection conn = JDBCTemplate.getConnection();
		// 1)게시글 정보 수정
		int result = new NoticeDao().updateNotice(conn, n);

		int result2 = 1;

		// 2)새롭게 첨부된 파일이 있는 경우
		if (at != null) {

			if (at.getFileNo() != 0) { // 기존 첨부파일이 있었던 경우 - update

				result2 = new NoticeDao().updateAttachment(conn, at);

			} else { // 기존 첨부파일이 없었던 경우 - insert
				// 기존 insertAttachment를 쓸 수 없는 이유: 기존에는 참조 게시글 번호를 게시글이 등록됨과
				// 동시에 currentValue를 잡아줬기 때문에 이미 뽑혀있는 시퀀스 번호를 찾으려면
				// 전달받아서 진행해야한다.
				result2 = new NoticeDao().insertNewAttachment(conn, at);

			}
		}

		// 게시글 정보 수정과 첨부파일 정보 수정이 둘다 올바르게 되었을 때를 알 수 있게 곱연산을 한다
		// 만약 둘 중 하나라도 실패하여 0이 나오면 result가 0이 되게끔
		int finalResult = result * result2;

		if (finalResult > 0) {
			JDBCTemplate.commit(conn);

		} else {
			JDBCTemplate.rollback(conn);

		}

		JDBCTemplate.close(conn);

		return finalResult;

	}


	
	//bookCount List 조회
	public ArrayList<BookCount> selectAjaxList() {
		
		Connection conn = JDBCTemplate.getConnection();

		ArrayList<BookCount> list = new NoticeDao().selectAjaxList(conn);

		JDBCTemplate.close(conn);

		return list;
		
	}

	

	//월별 (10월 11월 등) 대출권수 조회!!!
	public int monthCount(int cno, String month) {
		Connection conn = JDBCTemplate.getConnection();
		int rCount = new NoticeDao().monthCount(conn,cno,month);
		
		JDBCTemplate.close(conn);
		
		return rCount;
	}

	
	//topList3
	public ArrayList<Notice> selectTopList() {
		
		Connection conn = JDBCTemplate.getConnection();
		ArrayList<Notice> list= new NoticeDao().selectTopList(conn);
		
		JDBCTemplate.close(conn);
		
		return list;
	}

}
