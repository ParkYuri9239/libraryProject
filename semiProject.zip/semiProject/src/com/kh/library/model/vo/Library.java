package com.kh.library.model.vo;

public class Library {

	private String name;
	private String location;
	
	public Library() {
		super();
	}

	public Library(String name, String location) {
		super();
		this.name = name;
		this.location = location;
	}

	public Library(String location) {
		super();
		this.location = location;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Library [name=" + name + ", location=" + location + "]";
	}
	
	
	
	
	
}
