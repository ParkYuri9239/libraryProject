package com.kh.library.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.common.JDBCTemplate;
import com.kh.library.model.dao.LibraryDao;
import com.kh.library.model.vo.Library;

public class LibraryService {

	public ArrayList<Library> selectLibraryList() {
		Connection conn = JDBCTemplate.getConnection();
		
		ArrayList<Library> list =new LibraryDao().selectLibraryList(conn);
		
		JDBCTemplate.close(conn);
		
		return list;
		
	}

	public ArrayList<Library> selectLibrary(String location) {

		Connection conn = JDBCTemplate.getConnection();
		

		ArrayList<Library> list =new LibraryDao().selectLibrary(conn, location);
		
		JDBCTemplate.close(conn);
				
		return list;
	}
	

	


}
