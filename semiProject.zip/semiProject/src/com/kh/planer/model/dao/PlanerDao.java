package com.kh.planer.model.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.common.JDBCTemplate;
import com.kh.member.model.vo.Member;
import com.kh.planer.model.vo.Grade;
import com.kh.planer.model.vo.Planer;
import com.kh.planer.model.vo.Report;

public class PlanerDao {
	private Properties prop=new Properties();
	
	public PlanerDao() {
		try {
			prop.loadFromXML(new FileInputStream(PlanerDao.class.getResource("/db/sql/planer-mapper.xml").getPath()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public ArrayList<Planer> selectRentBook(Connection conn, int userNo) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("selectRentBook");
		ArrayList<Planer> list=new ArrayList<>();
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userNo);
			
			rset=pstmt.executeQuery();
			while(rset.next()) {
				list.add(new Planer(rset.getString("BOOK_TITLE")
									,rset.getDate("RENT_DATE")
									,rset.getDate("RETURN_DATE")
									,rset.getInt("EXTENSION_DATE")
									));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(conn);
		}
		
		return list;
		
	}
	public Report selectReportDetail(int rno, Connection conn) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("selectReportDetail");
		Report r=null;
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, rno);
			
			rset=pstmt.executeQuery();
			
			if(rset.next()) {
				r=new Report(rset.getInt("REPORT_NO"),
							rset.getString("USER_ID"),
							rset.getString("REPORT_TITLE"),
							rset.getString("REPORT_CONTENT"),
							rset.getDate("CREATE_DATE"),
							rset.getDate("MODIFY_DATE"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		return r;
		
	}
	public ArrayList<Report> selectReport(Connection conn, int userNo) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("selectReport");
		ArrayList<Report> list=new ArrayList<>();
		
		try {
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setInt(1, userNo);
			
			rset=pstmt.executeQuery();
			
			while(rset.next()) {
				list.add(new Report(rset.getInt("REPORT_NO"),
									rset.getInt("BOOK_NO"),
									rset.getString("REPORT_TITLE"),
									rset.getString("REPORT_CONTENT"),
									rset.getDate("CREATE_DATE"),
									rset.getDate("MODIFY_DATE"),
									rset.getString("CHANGE_NAME"),
									rset.getString("FILE_PATH")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		
		return list;
	}
	public int updateReport(Connection conn, int rno, String title, String content) {
		int result=0;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("updateReport");
		try {
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setInt(3, rno);
			
			result=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
	}
	public int deleteReport(int rno, Connection conn) {
		int result=0;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("deleteReport");
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, rno);
			
			result=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
		}
		
		return result;
	}
	public Grade selectGrade(Connection conn, int userNo) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("selectGrade");
		Grade g=null;
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userNo);
			
			rset=pstmt.executeQuery();
			if(rset.next()) {
				g=new Grade(rset.getString("GRADE_NAME"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
		}
		
		return g;
	}
	public int countRentBook(Connection conn, int userNo) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		int result=0;
		String sql=prop.getProperty("countRentBook");
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userNo);
			
			rset=pstmt.executeQuery();
			
			if(rset.next()) {
				result=rset.getInt("COUNT");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
	}
	public int countThisMonth(String month, int userNo, Connection conn) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("countMonth");
		int result=0;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, month);
			pstmt.setInt(2, userNo);
			
			rset=pstmt.executeQuery();
			
			if(rset.next()) {
				result=rset.getInt("COUNT");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		return result;
		
	}
	public int countPreMonth(int preMon, int userNo, Connection conn) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("countMonth");
		int result=0;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, preMon);
			pstmt.setInt(2, userNo);
			
			rset=pstmt.executeQuery();
			
			if(rset.next()) {
				result=rset.getInt("COUNT");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		return result;
	}
	public int countPrepreMonth(int prepreMon, int userNo, Connection conn) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("countMonth");
		int result=0;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, prepreMon);
			pstmt.setInt(2, userNo);
			
			rset=pstmt.executeQuery();
			
			if(rset.next()) {
				result=rset.getInt("COUNT");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		return result;
	}
	public ArrayList<Member> selectKing(Connection conn) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("selectKing");
		ArrayList<Member> list=new ArrayList<>();
		try {
			pstmt=conn.prepareStatement(sql);
			
			rset=pstmt.executeQuery();
			
			while(rset.next()){
					list.add(new Member(rset.getString("USER_ID"),
										rset.getInt("COUNT")));
				}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		
		return list;
	}
	public int insertReport(String title, String content, int userNo, int bno, Connection conn) {
		int result=0;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("insertReport");
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userNo);
			pstmt.setInt(2, bno);
			pstmt.setString(3, title);
			pstmt.setString(4, content);
			
			result=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
	}

}
