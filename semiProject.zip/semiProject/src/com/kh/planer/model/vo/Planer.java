package com.kh.planer.model.vo;

import java.sql.Date;

public class Planer {
	private int rbookNo;
	private String bookNo;
	private String userNo;
	private Date rentDate;
	private Date returnDate;
	private int extensionDate;
	public Planer() {
		super();
	}
	public Planer(int rbookNo, String bookNo, String userNo, Date rentDate, Date returnDate, int extensionDate) {
		super();
		this.rbookNo = rbookNo;
		this.bookNo = bookNo;
		this.userNo = userNo;
		this.rentDate = rentDate;
		this.returnDate = returnDate;
		this.extensionDate = extensionDate;
	}
	
	public Planer(String bookNo, Date rentDate, Date returnDate, int extensionDate) {
		super();
		this.bookNo = bookNo;
		this.rentDate = rentDate;
		this.returnDate = returnDate;
		this.extensionDate = extensionDate;
	}
	public int getRbookNo() {
		return rbookNo;
	}
	public void setRbookNo(int rbookNo) {
		this.rbookNo = rbookNo;
	}
	public String getBookNo() {
		return bookNo;
	}
	public void setBookNo(String bookNo) {
		this.bookNo = bookNo;
	}
	public String getUserNo() {
		return userNo;
	}
	public void setUserNo(String userNo) {
		this.userNo = userNo;
	}
	public Date getRentDate() {
		return rentDate;
	}
	public void setRentDate(Date rentDate) {
		this.rentDate = rentDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public int getExtensionDate() {
		return extensionDate;
	}
	public void setExtensionDate(int extensionDate) {
		this.extensionDate = extensionDate;
	}
	@Override
	public String toString() {
		return "Planer [rbookNo=" + rbookNo + ", bookNo=" + bookNo + ", userNo=" + userNo + ", rentDate=" + rentDate
				+ ", returnDate=" + returnDate + ", extensionDate=" + extensionDate + "]";
	}
	
	

}
