package com.kh.planer.model.vo;

import java.sql.Date;

public class Report {
	private int reportNo;
	private String userNo;
	private int bookNo;
	private String reportTitle;
	private String reportContent;
	private Date createDate;
	private Date modifyDate;
	private int count;
	
	
	
	private String changeName;
	private String filePath;
	
	
	public Report() {
		super();
	}
	public Report(int reportNo, String userNo, int bookNo, String reportTitle, String reportContent, Date createDate,
			Date modifyDate, int count) {
		super();
		this.reportNo = reportNo;
		this.userNo = userNo;
		this.bookNo = bookNo;
		this.reportTitle = reportTitle;
		this.reportContent = reportContent;
		this.createDate = createDate;
		this.modifyDate = modifyDate;
		this.count = count;
	}
	
	
	
	
	
	public Report(int reportNo, int bookNo, String reportTitle, String reportContent, Date createDate, Date modifyDate,
			String changeName, String filePath) {
		super();
		this.reportNo = reportNo;
		this.bookNo = bookNo;
		this.reportTitle = reportTitle;
		this.reportContent = reportContent;
		this.createDate = createDate;
		this.modifyDate = modifyDate;
		this.changeName = changeName;
		this.filePath = filePath;
	}
	public Report(int reportNo, String userNo, String reportTitle, String reportContent, Date createDate,
			Date modifyDate) {
		super();
		this.reportNo = reportNo;
		this.userNo = userNo;
		this.reportTitle = reportTitle;
		this.reportContent = reportContent;
		this.createDate = createDate;
		this.modifyDate = modifyDate;
	}
	public int getReportNo() {
		return reportNo;
	}
	public void setReportNo(int reportNo) {
		this.reportNo = reportNo;
	}
	public String getUserNo() {
		return userNo;
	}
	public void setUserNo(String userNo) {
		this.userNo = userNo;
	}
	public int getBookNo() {
		return bookNo;
	}
	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}
	public String getReportTitle() {
		return reportTitle;
	}
	public void setReportTitle(String reportTitle) {
		this.reportTitle = reportTitle;
	}
	public String getReportContent() {
		return reportContent;
	}
	public void setReportContent(String reportContent) {
		this.reportContent = reportContent;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	public String getChangeName() {
		return changeName;
	}
	public void setChangeName(String changeName) {
		this.changeName = changeName;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	@Override
	public String toString() {
		return "Report [reportNo=" + reportNo + ", userNo=" + userNo + ", bookNo=" + bookNo + ", reportTitle="
				+ reportTitle + ", reportContent=" + reportContent + ", createDate=" + createDate + ", modifyDate="
				+ modifyDate + ", count=" + count + "]";
	}
	
	
}	
