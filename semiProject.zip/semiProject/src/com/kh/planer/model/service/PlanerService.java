package com.kh.planer.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.common.JDBCTemplate;
import com.kh.member.model.vo.Member;
import com.kh.planer.model.dao.PlanerDao;
import com.kh.planer.model.vo.Grade;
import com.kh.planer.model.vo.Planer;
import com.kh.planer.model.vo.Report;

public class PlanerService {

	public ArrayList<Planer> selectRentBook(int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		ArrayList<Planer> list=new ArrayList<>();
		
		list=new PlanerDao().selectRentBook(conn,userNo);
		
		JDBCTemplate.close(conn);
		
		return list;
		
		
	}

	public Report selectReportDetail(int rno) {
		Connection conn=JDBCTemplate.getConnection();
		
		Report r=new PlanerDao().selectReportDetail(rno,conn);
		
		JDBCTemplate.close(conn);
		
		return r;
				
	}

	public ArrayList<Report> selectReprot(int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		
		ArrayList<Report> list=new PlanerDao().selectReport(conn,userNo);
		
		JDBCTemplate.close(conn);
		
		return list;
	}

	public int updateReport(int rno, String title, String content) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new PlanerDao().updateReport(conn,rno,title,content);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);
		
		return result;
	}

	public int deleteReport(int rno) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new PlanerDao().deleteReport(rno,conn);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);
		
		return result;
		
		
				
	}

	public Grade selectGrade(int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		
		Grade g=new PlanerDao().selectGrade(conn,userNo);
		
		JDBCTemplate.close(conn);
		
		return g;
				
	}

	public int countRentBook(int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		int result=new PlanerDao().countRentBook(conn,userNo);
		
		JDBCTemplate.close(conn);
		
		return result;
	}

	public int countThisMonth(String month, int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new PlanerDao().countThisMonth(month,userNo,conn);
		
		JDBCTemplate.close(conn);
		
		return result;

	}

	public int countPreMonth(int preMon, int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new PlanerDao().countPreMonth(preMon,userNo,conn);
		
		JDBCTemplate.close(conn);
		
		return result;
	}

	public int countPrepreMonth(int prepreMon, int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new PlanerDao().countPrepreMonth(prepreMon,userNo,conn);
		
		JDBCTemplate.close(conn);
		
		return result;
		
	}

	public ArrayList<Member> selectKing() {
		Connection conn=JDBCTemplate.getConnection();
		
		ArrayList<Member> list=new PlanerDao().selectKing(conn);
		
		JDBCTemplate.close(conn);
		
		return list;
	}

	public int insertReport(String title, String content, int userNo, int bno) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new PlanerDao().insertReport(title,content,userNo,bno,conn);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		
		return result;
	}

}
