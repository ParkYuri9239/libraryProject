package com.kh.planer.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.member.model.vo.Member;
import com.kh.planer.model.service.PlanerService;
import com.kh.planer.model.vo.Grade;
import com.kh.planer.model.vo.Planer;
import com.kh.planer.model.vo.Report;

/**
 * Servlet implementation class ReportListController
 */
@WebServlet("/view.p")
public class ReportListController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReportListController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Member loginUser=(Member)request.getSession().getAttribute("loginUser");
		int userNo=loginUser.getUserNo();
		
		LocalDate now = LocalDate.now();
		String now2=LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		String month=now2.substring(3,5);
		int preMon=Integer.parseInt(month)-1;
		int prepreMon=preMon-1;
		
		ArrayList<Report> list = new PlanerService().selectReprot(userNo);
		ArrayList<Planer> pList=new PlanerService().selectRentBook(userNo);
		Grade g=new PlanerService().selectGrade(userNo);
		int result=new PlanerService().countRentBook(userNo);
		int countM=new PlanerService().countThisMonth(month,userNo);
		int countPm=new PlanerService().countPreMonth(preMon,userNo);
		int countPpm=new PlanerService().countPrepreMonth(prepreMon,userNo);
		ArrayList<Member> mList= new PlanerService().selectKing();
		

		request.setAttribute("mList", mList);
		request.setAttribute("countPm", countPm);
		request.setAttribute("countPpm", countPpm);
		request.setAttribute("countM", countM);
		
		request.setAttribute("result", result);
		request.setAttribute("g", g);
		request.setAttribute("list", list);
		request.setAttribute("pList", pList);
		request.getRequestDispatcher("/views/planer/planerMainView.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
