package com.kh.planer.controller;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class RandomStringController
 */
@WebServlet("/random.do")
public class RandomStringController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RandomStringController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Random r=new Random();
		String[] str= {"<『미생』中> \n 잊지 말자. 나는 어머니의 자부심이다.",
				"<『도플갱어』中> \n 혼돈은 해석되기를 기다리는 질서일 뿐이다",
				"<『눈 뜬 자들의 도시』中>\n우리는 진실을 말할 때도 계속 거짓말을 하고,\n 거짓말을 할 때도 계속 진실을 말한다 ",
				"<『비행운』中>\n너는 자라 겨우 내가 되겠지" ,
				"<『미움받을 용기』中>\n 중요한 것은 무엇이 주어졌느냐가 아니라,\n 주어진 것을 어떻게 활용하느냐이다",
				"<『러브 앤 프리』中>\n사랑 받는 것에 너무 취해,\n 혹 사랑하는 일을 잊지는 않았나요?",
				"<『차라투스트라는 이렇게 말했다』中>\n세상을 바꾸는데는 신의 영향력보다 \n인간의 의지가 중요하다.",
				"<『죄와 벌』中>\n 나는 사람을 죽인 것이 아니다,\n 원칙을 죽인것이다!",
				"<『어떤 하루』中>\n인생은 남과 비교하는 것이 아니라,\n 어제의 나와 비교하는 것이다.",
				"<『위대한 개츠비』中>\n그러므로 우리는 물결을 거스르는 배처럼,\n 쉴 새 없이 과거 속으로 밀려나면서도\n 끝내 앞으로 나아가는 것이다.",
				"<『장미의 이름』中>\n지난날의 장미는 이제 그 이름뿐,\n 우리에게 남은 것은 그 덧없는 이름뿐."
				};
		
		response.setContentType("application/json; charset=UTF-8");
		
		new Gson().toJson(str,response.getWriter());
	
	
	
	}

}
