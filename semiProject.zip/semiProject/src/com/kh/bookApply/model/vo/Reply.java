package com.kh.bookApply.model.vo;

import java.sql.Date;

public class Reply {
	private int replyNo;
	private String writerNo;
	private int bookapplyNo;
	private int boardNo;
	private String replyContent;
	private Date createDate;
	public Reply() {
		super();
	}
	public Reply(int replyNo, String writerNo, int bookapplyNo, int boardNo, String replyContent, Date createDate) {
		super();
		this.replyNo = replyNo;
		this.writerNo = writerNo;
		this.bookapplyNo = bookapplyNo;
		this.boardNo = boardNo;
		this.replyContent = replyContent;
		this.createDate = createDate;
	}
	
	public Reply(int replyNo, String writerNo, String replyContent, Date createDate) {
		super();
		this.replyNo = replyNo;
		this.writerNo = writerNo;
		this.replyContent = replyContent;
		this.createDate = createDate;
	}
	public int getReplyNo() {
		return replyNo;
	}
	public void setReplyNo(int replyNo) {
		this.replyNo = replyNo;
	}
	public String getWriterNo() {
		return writerNo;
	}
	public void setWriterNo(String writerNo) {
		this.writerNo = writerNo;
	}
	public int getBookapplyNo() {
		return bookapplyNo;
	}
	public void setBookapplyNo(int bookapplyNo) {
		this.bookapplyNo = bookapplyNo;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getReplyContent() {
		return replyContent;
	}
	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	@Override
	public String toString() {
		return "Reply [replyNo=" + replyNo + ", writerNo=" + writerNo + ", bookapplyNo=" + bookapplyNo + ", boardNo="
				+ boardNo + ", replyContent=" + replyContent + ", createDate=" + createDate + "]";
	}
	
	

}
