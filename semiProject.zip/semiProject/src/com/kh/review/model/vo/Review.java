package com.kh.review.model.vo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.kh.board.model.vo.Board;
import com.kh.common.JDBCTemplate;
import com.kh.common.model.vo.PageInfo;

public class Review {
	
	private int rv_no;
	private int book_no; //게시글 번호
	private String rv_user_no;
	private int star_score;
	private String rv_content;
	private Date create_date;
	private String status;
	
	
	public Review() {
		super();
	}
	
	
	public Review(int star_score, String rv_content) {
		super();
		
		this.star_score = star_score;
		this.rv_content = rv_content;
	}
	

	public Review(String rv_user_no, int star_score, String rv_content, Date create_date) {
		super();
		this.rv_user_no = rv_user_no;
		this.star_score = star_score;
		this.rv_content = rv_content;
		this.create_date = create_date;
	}




	public Review(int rv_no, int book_no, String rv_user_no, int star_score, String rv_content, Date create_date,
			String status) {
		super();
		this.rv_no = rv_no;
		this.book_no = book_no;
		this.rv_user_no = rv_user_no;
		this.star_score = star_score;
		this.rv_content = rv_content;
		this.create_date = create_date;
		this.status = status;
	}



	public Review(int rv_no, String rv_user_no, int star_score, String rv_content, Date create_date) {
		super();
		this.rv_no = rv_no;
		this.rv_user_no = rv_user_no;
		this.star_score = star_score;
		this.rv_content = rv_content;
		this.create_date = create_date;
	}


	public int getRv_no() {
		return rv_no;
	}


	public void setRv_no(int rv_no) {
		this.rv_no = rv_no;
	}


	public int getBook_no() {
		return book_no;
	}


	public void setBook_no(int book_no) {
		this.book_no = book_no;
	}


	public String getRv_user_no() {
		return rv_user_no;
	}


	public void setRv_user_no(String rv_user_no) {
		this.rv_user_no = rv_user_no;
	}


	public int getStar_score() {
		return star_score;
	}


	public void setStar_score(int star_score) {
		this.star_score = star_score;
	}


	public String getRv_content() {
		return rv_content;
	}


	public void setRv_content(String rv_content) {
		this.rv_content = rv_content;
	}


	public Date getCreate_date() {
		return create_date;
	}


	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public String toString() {
		return "Review [rv_no=" + rv_no + ", book_no=" + book_no + ", rv_user_no=" + rv_user_no + ", star_score="
				+ star_score + ", rv_content=" + rv_content + ", create_date=" + create_date + ", status=" + status
				+ "]";
	}
	
	


	
	
	

}
