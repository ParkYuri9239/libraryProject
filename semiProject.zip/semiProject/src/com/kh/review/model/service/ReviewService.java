package com.kh.review.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.board.model.dao.BoardDao;
import com.kh.board.model.vo.Board;
import com.kh.board.model.vo.Reply;
import com.kh.common.JDBCTemplate;
import com.kh.common.model.vo.PageInfo;
import com.kh.member.model.dao.MemberDao;
import com.kh.member.model.vo.Member;
import com.kh.review.model.dao.ReviewDao;
import com.kh.review.model.vo.Review;
import com.kh.search.model.dao.SearchDao;

public class ReviewService {

	
//	  public ArrayList<Review> insertreview(int reviewStar, String contents) {
//	  Connection conn = JDBCTemplate.getConnection(); ArrayList<Review> list = new
//	  ReviewDao().insertreview(conn,reviewStar,contents);
//	  
//	  JDBCTemplate.close(conn);
//	  
//	  return list; }
	 

	
	
	public int insertReview(Review r) {
		Connection conn = JDBCTemplate.getConnection();
		
		int result = new ReviewDao().insertReview(conn,r);
		
			if(result>0) {
				JDBCTemplate.commit(conn);
			}else {
				JDBCTemplate.rollback(conn);
			}
		
		JDBCTemplate.close(conn);
		
		
		return result;
	}
	
	
	
	//댓글 리스트 조회 메소드
	public ArrayList<Review> selectReviewList(int bno) {
		Connection conn = JDBCTemplate.getConnection();
		
		ArrayList<Review> list = new ReviewDao().selectReviewList(conn,bno);
		
		JDBCTemplate.close(conn);
		
		return list;
		
	}

	
	

	//댓글 삭제
	public int deleteReview(int rno) {
		Connection conn = JDBCTemplate.getConnection();
		
		int result =new ReviewDao().deleteReview(conn,rno);
		
		if(result>0) {
			JDBCTemplate.commit(conn);			
		}else {
			JDBCTemplate.rollback(conn);
		}
		
		JDBCTemplate.close(conn);
		
		return result;
	}
	
	
	

	//사용자 요청 페이지 목록 메소드
	public ArrayList<Review> selectReviewList(PageInfo pi) {
		Connection conn = JDBCTemplate.getConnection();
		
		ArrayList<Review> list = new ReviewDao().selectList(conn,pi);
		
		JDBCTemplate.close(conn);
		
		return list;
				
	}



	public int selectReviewListCount() {
		Connection conn = JDBCTemplate.getConnection();
		
		int count = new ReviewDao().selectReviewListCount(conn);
		
		JDBCTemplate.close(conn);
		
		return count;
	}
	
	

}
