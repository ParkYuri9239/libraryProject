package com.kh.review.model.dao;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.board.model.vo.Board;
import com.kh.common.JDBCTemplate;
import com.kh.common.model.vo.PageInfo;
import com.kh.review.model.vo.Review;
public class ReviewDao {
	
	private Properties prop = new Properties();
	
	//기본생성자
		public ReviewDao() {
			String filePath = ReviewDao.class.getResource("/db/sql/review-mapper.xml").getPath();
			
			try {
				prop.loadFromXML(new FileInputStream(filePath));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		


	
	
	//리플
		public int insertReview(Connection conn, Review r) {
			int result = 0;
			PreparedStatement pstmt = null;
			String sql = prop.getProperty("insertReview");
			
			try {
				pstmt = conn.prepareStatement(sql);
				System.out.println(r.getBook_no());
				
				pstmt.setInt(1, r.getBook_no());
				pstmt.setInt(2, Integer.parseInt(r.getRv_user_no()));
				pstmt.setInt(3, r.getStar_score());
				pstmt.setString(4, r.getRv_content());
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				JDBCTemplate.close(pstmt);
			}
			
			return result;
		}

		
		
		
		
		//댓글 리스트 조회 메소드
		public ArrayList<Review> selectReviewList(Connection conn, int bno) {
			
			ArrayList<Review> list = new ArrayList<>();
			
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			String sql = prop.getProperty("selectReviewList");
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, bno);
				
				/*
				 * pstmt.setInt(2, r.getStar_score()); pstmt.setString(3, r.getRv_content());
				 */		
				
				rset = pstmt.executeQuery();
				
				while(rset.next()) {
					list.add(new Review(rset.getInt("RV_NO")
							,rset.getString("USER_ID")
							,rset.getInt("STAR_SCORE")
							,rset.getString("RV_CONTENT")
							,rset.getDate("CREATE_DATE")));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				JDBCTemplate.close(rset);
				JDBCTemplate.close(pstmt);
			}
			
			System.out.println("000000000000000"+list);
			
			return list;
		
		}


		


		//댓글 삭제
		public int deleteReview(Connection conn, int rno) {
			int result = 0;
			PreparedStatement pstmt = null;
			String sql = prop.getProperty("deleteReview");
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, rno);
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				JDBCTemplate.close(pstmt);
			}
			return result;

		}




		//사용자 요청 페이지 목록 메소드
		public ArrayList<Review> selectList(Connection conn, PageInfo pi) {
			
			//select 문 
			ResultSet rset = null;
			ArrayList<Review> list = new ArrayList<>();
			PreparedStatement pstmt = null;
			
			String sql = prop.getProperty("selectRiviewList");
			/*
			 * boardLimit이  10이라고 가정하면
			 * currentPage = 1 -> 시작값:1  끝값:10
			 * currentPage = 2 -> 시작값:11 끝값:20
			 * currentPage = 3 -> 시작값:21 끝값:30
			 * 
			 * 시작값 = (currentPage - 1) * boardLimit + 1
			 * 끝값 = currentPage * boardLimit
			 * */
			
			int startRow = (pi.getCurrentPage()-1) * pi.getBoardLimit()+1;
			int endRow = pi.getCurrentPage() * pi.getBoardLimit();
			
			try {
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setInt(1, startRow);
				pstmt.setInt(2, endRow);
				
				rset = pstmt.executeQuery();
				
				while(rset.next()) {
					
					list.add(new Review(rset.getInt("RV_NO")
							,rset.getString("USER_ID")
							,rset.getInt("STAR_SCORE")
							,rset.getString("RV_CONTENT")
							,rset.getDate("CREATE_DATE")));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				JDBCTemplate.close(rset);
				JDBCTemplate.close(pstmt);
			}

			
			return list;
		}





		public int selectReviewListCount(Connection conn) {
				
				int listCount = 0;
				
				PreparedStatement pstmt = null;
				ResultSet rset = null;
				
				String sql = prop.getProperty("selectReviewListCount");
				
				try {
					pstmt = conn.prepareStatement(sql);
					
					rset = pstmt.executeQuery();
					
					if(rset.next()) {
						//조회된 게시글 개수
						listCount = rset.getInt("COUNT");
					
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					JDBCTemplate.close(rset);
					JDBCTemplate.close(pstmt);
				}
				
				
				return listCount;
			
		}
	
}


