package com.kh.review.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.review.model.service.ReviewService;

/**
 * Servlet implementation class reviewDeleteController
 */
@WebServlet("/rdelete.rv")
public class ReviewDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReviewDeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	  protected void doPost(HttpServletRequest request, HttpServletResponse
	  response) throws ServletException, IOException {
	  
	  //삭제하기
		  int rno = Integer.parseInt(request.getParameter("rvno"));
          int result = new ReviewService().deleteReview(rno);
          
          System.out.println("삭제 완료");
	  
	  if(result>0) { //공지 삭제 성공시 alertMsg로 공지사항 삭제 성공 메세지 띄우면서 공지사항 리스트 보여주기
			  request.getSession().setAttribute("alertMsg", "리뷰 삭제 성공");
			  //response.sendRedirect(request.getContextPath()+"/list.rv?currentPage=1");
			  //response.sendRedirect(request.getContextPath()+"/list.bo");
			  
			  response.setContentType("text/html; charset=UTF-8");
			  response.getWriter().print(result);
			  
	  
	  }else { //실패시 에러페이지에 공지사항 삭제 실패 메세지 띄우기 request.setAttribute("errorMsg","리뷰 삭제 실패");
			  request.getRequestDispatcher("/views/common/errorPage.jsp").forward(request,
			  response); }
	  
	  }
	 

}
