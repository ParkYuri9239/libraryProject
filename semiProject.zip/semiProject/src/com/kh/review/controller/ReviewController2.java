package com.kh.review.controller;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.member.model.vo.Member;
import com.kh.review.model.service.ReviewService;
import com.kh.review.model.vo.Review;
import com.kh.search.model.service.SearchService;

/**
 * Servlet implementation class reviewController2
 */
@WebServlet("/reviewForm2.rv")
public class ReviewController2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ReviewController2() { 
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		request.setCharacterEncoding("UTF-8");

		 int rvno = Integer.parseInt(request.getParameter("rvno"));
		
		 Member loginUser = (Member)request.getSession().getAttribute("loginUser");
		 int userNo = loginUser.getUserNo();

		String content = request.getParameter("reviewContents");
		int star = Integer.parseInt(request.getParameter("reviewStar"));
		//int star = Integer.parseInt(request.getParameter("reviewStar"));
		
		System.out.println("나 스타" + star);
		
		
		Review r = new Review();
		r.setRv_content(content);
		r.setStar_score(star);
		r.setBook_no(rvno);
		r.setRv_user_no((String.valueOf(userNo)));
		/*
		 * r.setRv_no(rvNo);
		 * 
		 * System.out.println("아무거나"+r);
		 */

		int result = new ReviewService().insertReview(r);
		
		response.getWriter().print(result);
		
		

	}

}
