package com.kh.book.model.vo;

import java.sql.Date;

public class Book {
	
	private int bookNo;
	private int genreNo;
	private String bookTitle;
	private String author;
	private String bookInfo;
	private int rentCount;
	private Date createBook;
	private String status;
	private String filePath;						
	private String changeName;						
	
	
	public Book() {
		super();
	}

	public Book(int bookNo, int genreNo, String bookTitle, String author, String bookInfo, int rentCount,
			Date createBook, String status) {
		super();
		this.bookNo = bookNo;
		this.genreNo = genreNo;
		this.bookTitle = bookTitle;
		this.author = author;
		this.bookInfo = bookInfo;
		this.rentCount = rentCount;
		this.createBook = createBook;
		this.status = status;
	}
	
	public Book(int bookNo, int genreNo, String bookTitle, String author, String bookInfo, int rentCount,
			Date createBook) {
		super();
		this.bookNo = bookNo;
		this.genreNo = genreNo;
		this.bookTitle = bookTitle;
		this.author = author;
		this.bookInfo = bookInfo;
		this.rentCount = rentCount;
		this.createBook = createBook;
	}

	

	public Book(int bookNo, int genreNo, String bookTitle, String author, String bookInfo, int rentCount) {
		super();
		this.bookNo = bookNo;
		this.genreNo = genreNo;
		this.bookTitle = bookTitle;
		this.author = author;
		this.bookInfo = bookInfo;
		this.rentCount = rentCount;
	}
	

	

	public Book(int bookNo, String bookTitle, String author, String filePath, String changeName) {
		super();
		this.bookNo = bookNo;
		this.bookTitle = bookTitle;
		this.author = author;
		this.filePath = filePath;
		this.changeName = changeName;
	}

	public int getBookNo() {
		return bookNo;
	}

	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}

	public int getGenreNo() {
		return genreNo;
	}

	public void setGenreNo(int genreNo) {
		this.genreNo = genreNo;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getBookInfo() {
		return bookInfo;
	}

	public void setBookInfo(String bookInfo) {
		this.bookInfo = bookInfo;
	}

	public int getRentCount() {
		return rentCount;
	}

	public void setRentCount(int rentCount) {
		this.rentCount = rentCount;
	}

	public Date getCreateBook() {
		return createBook;
	}

	public void setCreateBook(Date createBook) {
		this.createBook = createBook;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getChangeName() {
		return changeName;
	}

	public void setChangeName(String changeName) {
		this.changeName = changeName;
	}

	@Override
	public String toString() {
		return "Book [bookNo=" + bookNo + ", genreNo=" + genreNo + ", bookTitle=" + bookTitle + ", author=" + author
				+ ", bookInfo=" + bookInfo + ", rentCount=" + rentCount + ", createBook=" + createBook + ", status="
				+ status + ", filePath=" + filePath + ", changeName=" + changeName + "]";
	}
	
	
	
	
	
}








