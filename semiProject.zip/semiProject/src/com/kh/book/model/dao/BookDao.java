package com.kh.book.model.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.book.model.vo.Book;
import com.kh.common.JDBCTemplate;

public class BookDao {

	private Properties prop = new Properties();
	
	public BookDao() {
		String filePath = BookDao.class.getResource("/db/sql/book-mapper.xml").getPath();
		
		try {
			prop.loadFromXML(new FileInputStream(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<Book> selectBookList(Connection conn) {
		
		ArrayList<Book> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectBookList");
		
		try {
			pstmt = conn.prepareStatement(sql);
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
				list.add(new Book(rset.getInt("BOOK_NO")
						           ,rset.getInt("GENRE_NO")
						           ,rset.getString("BOOK_TITLE")
						           ,rset.getString("AUTHOR")
						           ,rset.getString("BOOK_INFO")
						           ,rset.getInt("RENT_COUNT")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

		
	}

	public ArrayList<Book> selecBook(Connection conn) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("selectBook");
		ArrayList<Book> list=new ArrayList<>();
		
		try {
			pstmt=conn.prepareStatement(sql);
			
			rset=pstmt.executeQuery();
			
			while(rset.next()) {
				list.add(new Book(rset.getInt("BOOK_NO"),
								  rset.getString("BOOK_TITLE"),
								  rset.getString("AUTHOR"),
								  rset.getString("FILE_PATH"),
								  rset.getString("CHANGE_NAME")));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		System.out.println("dao"+list);
		return list;
				
	}

}
