package com.kh.book.model.service;


import java.sql.Connection;
import java.util.ArrayList;

import com.kh.book.model.dao.BookDao;
import com.kh.book.model.vo.Book;
import com.kh.common.JDBCTemplate;

public class BookService {

	public ArrayList<Book> selectBook() {
		
		Connection conn=JDBCTemplate.getConnection();
		
		ArrayList<Book> list=new BookDao().selecBook(conn);
		
		JDBCTemplate.close(conn);
		
		return list;
		
		
		
	}

}
