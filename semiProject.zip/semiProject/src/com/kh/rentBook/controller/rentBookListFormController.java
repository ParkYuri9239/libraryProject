package com.kh.rentBook.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.member.model.vo.Member;
import com.kh.rentBook.model.service.rentBookService;
import com.kh.rentBook.model.vo.RentBook;

/**
 * Servlet implementation class rentBookListFormController
 */
@WebServlet("/rentForm.re")
public class rentBookListFormController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public rentBookListFormController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		Member loginUser = (Member) request.getSession().getAttribute("loginUser");
		int userNo = loginUser.getUserNo();
		
		ArrayList<RentBook> rList = new rentBookService().selectRentList(userNo);
		int bno=0;
		int result=0;
		for(int i=0; i<rList.size(); i++) {
			if(rList.get(i).getReturnDate().equals(rList.get(i).getSysd())) {
				System.out.println(i + "," +rList.get(i).getBookTitle());
				bno = rList.get(i).getBookNo();
				
				result = new rentBookService().returnBook(userNo, bno);
				
				rList = new rentBookService().selectRentList(userNo);
			}
		}
		
		if(result > 0 && rList != null) {
			session.setAttribute("alertMsg", "반납날짜가 된 도서는 삭제되었습니다");
			request.setAttribute("rList", rList);
			request.getRequestDispatcher("/views/rentBook/bookRentListView.jsp").forward(request, response);
			
		}
		
		if(rList!=null && result<=0) {
			request.setAttribute("rList", rList);
			request.getRequestDispatcher("/views/rentBook/bookRentListView.jsp").forward(request, response);
			
		}else {
			System.out.println("조회 실패");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
