package com.kh.rentBook.model.vo;

public class BookAttachment {
	
	private int bookNo;
	private String filePath;
	private String originName;
	private String changeName;
	public BookAttachment() {
		super();
	}
	public BookAttachment(int bookNo, String filePath, String originName, String changeName) {
		super();
		this.bookNo = bookNo;
		this.filePath = filePath;
		this.originName = originName;
		this.changeName = changeName;
	}
	public int getBookNo() {
		return bookNo;
	}
	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getOriginName() {
		return originName;
	}
	public void setOriginName(String originName) {
		this.originName = originName;
	}
	public String getChangeName() {
		return changeName;
	}
	public void setChangeName(String changeName) {
		this.changeName = changeName;
	}
	@Override
	public String toString() {
		return "BookAttachment [bookNo=" + bookNo + ", filePath=" + filePath + ", originName=" + originName
				+ ", changeName=" + changeName + "]";
	}
	
	
	
	
}
