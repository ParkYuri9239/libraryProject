package com.kh.rentBook.model.vo;

import java.sql.Date;
/*
RBOOK_NO,
BOOK_NO,
B.BOOK_TITLE BOOK_TITLE,
AUTHOR,
USER_NO,
RENT_DATE,
RETURN_DATE,
EXTENSION_DATE,
R.STATUS STATUS
 * */
public class RentBook {
	private int rbookNo;
	private int bookNo;
	private String bookTitle;
	private String author;
	private int userNo;
	private Date rentDate;
	private Date returnDate;
	private int extensionDate;
	private String status;
	private Date sysd;
	private String filePath;
	private String originName;
	private String changeName;
	
	
	
	
	
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getOriginName() {
		return originName;
	}
	public void setOriginName(String originName) {
		this.originName = originName;
	}
	public String getChangeName() {
		return changeName;
	}
	public void setChangeName(String changeName) {
		this.changeName = changeName;
	}
	public RentBook(int rbookNo, int bookNo, String bookTitle, String author, int userNo, Date rentDate,
			Date returnDate, int extensionDate, String status, Date sysd, String filePath, String originName,
			String changeName) {
		super();
		this.rbookNo = rbookNo;
		this.bookNo = bookNo;
		this.bookTitle = bookTitle;
		this.author = author;
		this.userNo = userNo;
		this.rentDate = rentDate;
		this.returnDate = returnDate;
		this.extensionDate = extensionDate;
		this.status = status;
		this.sysd = sysd;
		this.filePath = filePath;
		this.originName = originName;
		this.changeName = changeName;
	}
	public RentBook(int rbookNo, int bookNo, String bookTitle, String author, int userNo, Date rentDate,
			Date returnDate, int extensionDate, String status, Date sysd) {
		super();
		this.rbookNo = rbookNo;
		this.bookNo = bookNo;
		this.bookTitle = bookTitle;
		this.author = author;
		this.userNo = userNo;
		this.rentDate = rentDate;
		this.returnDate = returnDate;
		this.extensionDate = extensionDate;
		this.status = status;
		this.sysd = sysd;
	}
	public Date getSysd() {
		return sysd;
	}
	public void setSysd(Date sysd) {
		this.sysd = sysd;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public RentBook(int rbookNo, int bookNo, String bookTitle, String author, int userNo, Date rentDate,
			Date returnDate, int extensionDate, String status) {
		super();
		this.rbookNo = rbookNo;
		this.bookNo = bookNo;
		this.bookTitle = bookTitle;
		this.author = author;
		this.userNo = userNo;
		this.rentDate = rentDate;
		this.returnDate = returnDate;
		this.extensionDate = extensionDate;
		this.status = status;
	}
	public RentBook() {
		super();
	}
	public RentBook(int rbookNo, int bookNo, int userNo, Date rentDate, Date returnDate, int extensionDate,
			String status) {
		super();
		this.rbookNo = rbookNo;
		this.bookNo = bookNo;
		this.userNo = userNo;
		this.rentDate = rentDate;
		this.returnDate = returnDate;
		this.extensionDate = extensionDate;
		this.status = status;
	}
	public int getRbookNo() {
		return rbookNo;
	}
	public void setRbookNo(int rbookNo) {
		this.rbookNo = rbookNo;
	}
	public int getBookNo() {
		return bookNo;
	}
	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public Date getRentDate() {
		return rentDate;
	}
	public void setRentDate(Date rentDate) {
		this.rentDate = rentDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public int getExtensionDate() {
		return extensionDate;
	}
	public void setExtensionDate(int extensionDate) {
		this.extensionDate = extensionDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "RentBook [rbookNo=" + rbookNo + ", bookNo=" + bookNo + ", userNo=" + userNo + ", rentDate=" + rentDate
				+ ", returnDate=" + returnDate + ", extensionDate=" + extensionDate + ", status=" + status + "]";
	}
	
}
