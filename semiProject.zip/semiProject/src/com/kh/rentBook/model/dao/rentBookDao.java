package com.kh.rentBook.model.dao;
import java.io.FileInputStream;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.bookBoard.model.vo.Book;
import com.kh.common.JDBCTemplate;
import com.kh.rentBook.model.vo.RentBook;

public class rentBookDao {
private Properties prop = new Properties();
	
	public rentBookDao() {
		String filePath = rentBookDao.class.getResource("/db/sql/bookRent-mapper.xml").getPath();
	
		try {
			prop.loadFromXML(new FileInputStream(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<RentBook> selectRentList(Connection conn, int userNo) {
		ArrayList<RentBook> rList = new ArrayList<>();
		ResultSet rset = null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectRentList");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userNo);
			rset = pstmt.executeQuery();
			while(rset.next()) {
				/*
			RBOOK_NO,
	        BOOK_NO,
	        B.BOOK_TITLE BOOK_TITLE,
	        AUTHOR,
	        USER_NO,
	        RENT_DATE,
	        RETURN_DATE,
	        EXTENSION_DATE,
	        R.STATUS STATUS
				 * */
				
				rList.add(new RentBook(
							rset.getInt("RBOOK_NO"),
							rset.getInt("BOOK_NO"),
							rset.getString("BOOK_TITLE"),
							rset.getString("AUTHOR"),
							rset.getInt("USER_NO"),
							rset.getDate("RENT_DATE"),
							rset.getDate("RETURN_DATE"),
							rset.getInt("EXTENSION_DATE"),
							rset.getString("STATUS"),
							rset.getDate("SYSD"),
							rset.getString("FILE_PATH"),
							rset.getString("ORIGIN_NAME"),
							rset.getString("CHANGE_NAME")
							
						));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		
		return rList;
	}

	public int returnBook(Connection conn, int userNo, int bno) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("returnBook");
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			pstmt.setInt(2, userNo);
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("dao " + result);
		return result;
		
	}
	
	
	
	
	
	
	
	
	
	
}
