package com.kh.rentBook.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.bookBoard.model.dao.BookBoardDao;
import com.kh.bookBoard.model.service.BookBoardService;
import com.kh.bookBoard.model.vo.Book;
import com.kh.common.JDBCTemplate;
import com.kh.rentBook.model.dao.rentBookDao;
import com.kh.rentBook.model.vo.RentBook;

public class rentBookService {

	public ArrayList<RentBook> selectRentList(int userNo) {
		
		Connection conn = JDBCTemplate.getConnection();
		
		ArrayList<RentBook> rList = new rentBookDao().selectRentList(conn, userNo);
		
		JDBCTemplate.close(conn);
		
		
		return rList;
	}

	public int returnBook(int userNo, int bno) {
		Connection conn = JDBCTemplate.getConnection();
		
		int result = new rentBookDao().returnBook(conn, userNo, bno);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		
		JDBCTemplate.close(conn);
		return result;
	}


}
