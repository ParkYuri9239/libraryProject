package com.kh.bookBoard.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.bookBoard.model.service.BookBoardService;
import com.kh.bookBoard.model.vo.Book;
import com.kh.member.model.vo.Member;
import com.kh.rentBook.model.service.rentBookService;
import com.kh.rentBook.model.vo.RentBook;

/**
 * Servlet implementation class bookLikeFormController
 */
@WebServlet("/likeForm.bo")
public class bookLikeFormController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bookLikeFormController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Member loginUser=(Member)request.getSession().getAttribute("loginUser");
		int userNo=loginUser.getUserNo();
		
		ArrayList<Book> list=new BookBoardService().selectLike(userNo);
		
		ArrayList<RentBook> rList = new rentBookService().selectRentList(userNo);
		
		request.setAttribute("list", list);
		request.setAttribute("rList", rList);
		request.getRequestDispatcher("/views/bookBoard/bookLikeView.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
