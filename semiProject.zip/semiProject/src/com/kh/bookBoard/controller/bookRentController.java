package com.kh.bookBoard.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.bookBoard.model.service.BookBoardService;
import com.kh.member.model.vo.Member;

/**
 * Servlet implementation class bookRentController
 */
@WebServlet("/rent.bo")
public class bookRentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bookRentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int bno = Integer.parseInt(request.getParameter("bno"));
		Member loginUser = (Member) request.getSession().getAttribute("loginUser");
		
		int userNo = loginUser.getUserNo();
		
		int count = new BookBoardService().rentbookChk(bno, userNo);
		System.out.println("count: " + count);
		if(count==0) {
			int result = new BookBoardService().rentbookInsert(bno, userNo);
			
			if(result>0) {
				session.setAttribute("alertMsg", "대출하였습니다.대출 도서 목록으로 이동합니다.");
				response.sendRedirect(request.getContextPath()+ "/rentForm.re");
			} else {
				session.setAttribute("alertMsg", "대출실패");
				response.sendRedirect(request.getHeader("referer"));
			}
		} else {
			session.setAttribute("alertMsg", "이미 대출 한 도서이거나 대출이 불가능한 도서입니다");
			response.sendRedirect(request.getHeader("referer"));
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
