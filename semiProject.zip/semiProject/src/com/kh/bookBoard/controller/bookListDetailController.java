package com.kh.bookBoard.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.bookBoard.model.service.BookBoardService;
import com.kh.bookBoard.model.vo.Book;
import com.kh.notice.model.service.NoticeService;
import com.kh.notice.model.vo.BookClick;
import com.kh.notice.model.vo.BookCount;

/**
 * Servlet implementation class bookListDetailController
 */
@WebServlet("/detail.bo")
public class bookListDetailController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bookListDetailController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int bno = Integer.parseInt(request.getParameter("bno"));
		
		Book b = new BookBoardService().selectBook(bno);
	
		// 1. 조회수 올리기  ///////
		int result = new BookBoardService().increaseBookCount(bno);
		
		if(b != null&&result>0) {
		
			//2. 게시물 한개 중 조회수 담겨 있으니 bc에 담는다
			Book bc = new BookBoardService().selectBookCount(bno);
			
			int count = new BookBoardService().rentCount(bno);	
			//최근30일이내 대출권수!!!!!!!
			request.setAttribute("count", count);
					
					
//			LocalDate now = LocalDate.now();
//					
//			String now2=LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
//			String month=now2.substring(3,5);
					
			//3. 월별 (10월 11월 등) 대출권수 조회 ////
			//int rCount = new NoticeService().monthCount(bno,month);
					
			//count와 month에 담겨있다
			//request.setAttribute("month", month);
	
			request.setAttribute("book", b);
			request.setAttribute("bookC", bc);
			
			
			request.getRequestDispatcher("/views/bookBoard/bookDetailView.jsp").forward(request, response);
			
			
			
		}else {
			System.out.println("조회 실패");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
