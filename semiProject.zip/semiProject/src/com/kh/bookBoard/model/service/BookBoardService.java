package com.kh.bookBoard.model.service;

import java.sql.Connection;


import java.util.ArrayList;

import com.kh.bookBoard.model.dao.BookBoardDao;
import com.kh.bookBoard.model.vo.Book;
import com.kh.bookBoard.model.vo.Cover;
import com.kh.bookBoard.model.vo.Genre;
import com.kh.common.JDBCTemplate;
import com.kh.notice.model.dao.NoticeDao;
import com.kh.notice.model.vo.BookClick;
import com.kh.notice.model.vo.BookCount;
import com.kh.rentBook.model.vo.BookAttachment;

public class BookBoardService {

	public ArrayList<Book> selectBookList(String search) {
		Connection conn = JDBCTemplate.getConnection();
		
		ArrayList<Book> list = new BookBoardDao().selectBookList(conn, search);
		
		JDBCTemplate.close(conn);
		
		return list;
	}
	
	

	public Book selectBook(int bno) {
		Connection conn = JDBCTemplate.getConnection();
		
		Book b = new BookBoardDao().selectBook(conn, bno);
		
		JDBCTemplate.close(conn);
		return b;
	}

	public ArrayList<Genre> selectCategoryList() {
		Connection conn = JDBCTemplate.getConnection();
		
		ArrayList<Genre> glist = new BookBoardDao().selectCategoryList(conn);
		
		return glist;
		
	}

	public int insertBoard(Book b, Cover c, BookAttachment ba) {
		Connection conn = JDBCTemplate.getConnection();
		int result1 = new BookBoardDao().insertBoard(conn, b);
		
		int result2 = 1;
		int result3 = 1;
		if(c != null && ba != null) {
			result2=new BookBoardDao().insertBoard(conn, c);
			result3= new BookBoardDao().insertBookAttachment(conn, ba);
		}
		if((result1 * result2)>0) {
			//첨부파일이 없는경우에 result2를 0으로 초기화 해 둔다면 insert가 성공했을 때도
			//result2는 여전히 0이라서 rollback처리가 될것이기 때문에
			//result2의 초기값을 1로 초기화해둔다.
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		
		return result1* result2;
		
	}

	public int deleteBook(int bno) {
		
		Connection conn = JDBCTemplate.getConnection();
		
		int result = new BookBoardDao().deleteBook(conn, bno);
		
		JDBCTemplate.close(conn);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		
		return result;
	}

	public Cover selectCover(int bno) {
		Connection conn = JDBCTemplate.getConnection();
		
		Cover c = new BookBoardDao().selectCover(conn, bno);
		
		JDBCTemplate.close(conn);
		return c;
	}

	public int updateBook(Book b, Cover c, BookAttachment ba) {
		
		Connection conn = JDBCTemplate.getConnection();
		
		int result = new BookBoardDao().updateBook(conn, b);
		
		int result2 = new BookBoardDao().updateCover(conn, c);
		
		int result3 = new BookBoardDao().updateBookAttachment(conn, ba);
		
		if(result * result2 * result3 > 0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		
		
		return result *result2 * result3;
		
		
		
	}

	public int selectListCount() {
		
		Connection conn = JDBCTemplate.getConnection();
		
		int result = new BookBoardDao().selectListCount(conn);
		
		JDBCTemplate.close(conn);
		
		return result;
	}

	public int rentbookInsert(int bno, int userNo) {
		
		Connection conn = JDBCTemplate.getConnection();
		
		int result = new BookBoardDao().rentbookInsert(conn, bno, userNo);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		
		
		
		
		return result;
	}

	public int rentbookChk(int bno, int userNo) {
		
		Connection conn = JDBCTemplate.getConnection();
		
		int count = new BookBoardDao().rentbookChk(conn, bno, userNo);
		
		return count;
	}

	public BookAttachment selectBookAttachment(int bno) {
		
		Connection conn = JDBCTemplate.getConnection();
		
		BookAttachment ba = new BookBoardDao().selectBookAttachment(conn, bno);
		
		JDBCTemplate.close(conn);
		
		return ba;
	}
	public int insertLike(int userNo, int bno) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new BookBoardDao().insertLike(conn,userNo,bno);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		
		return result;
	}

	public ArrayList<Book> selectLike(int userNo) {
		Connection conn=JDBCTemplate.getConnection();
		
		ArrayList<Book> list=new BookBoardDao().selectLike(userNo,conn);
		
		JDBCTemplate.close(conn);
		
		return list;
		
	}

	public int deleteLike(int userNo, int bno) {
		Connection conn=JDBCTemplate.getConnection();
		
		int result=new BookBoardDao().deleteLike(conn,userNo,bno);
		
		if(result>0) {
			JDBCTemplate.commit(conn);
		}else {
			JDBCTemplate.rollback(conn);
		}
		
		return result;
	}
	
	public int increaseBookCount(int bno) {

		Connection conn = JDBCTemplate.getConnection();

		int result = new BookBoardDao().increaseBookCount(conn, bno);

		
		
		if (result > 0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);

		System.out.println("나는 서비스 리절트"+result);

		return result;

	}

	//bookCount조회
	public Book selectBookCount(int bno) {
		
		Connection conn = JDBCTemplate.getConnection();

		Book bc = new BookBoardDao().selectBookCount(conn, bno);

		JDBCTemplate.close(conn);

		return bc;
	}
	
	//rentCount 조회 최근30일이내 대출권수!!!!!!!
		public int rentCount(int bno) {
		
		Connection conn = JDBCTemplate.getConnection();
		
		int count = new BookBoardDao().rentCount(conn,bno);
		
		JDBCTemplate.close(conn);
		
		return count;
		
	}


}
