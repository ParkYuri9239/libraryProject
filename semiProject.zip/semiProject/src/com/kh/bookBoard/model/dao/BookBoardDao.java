package com.kh.bookBoard.model.dao;

import java.io.FileInputStream;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.bookBoard.model.vo.Book;
import com.kh.bookBoard.model.vo.Cover;
import com.kh.bookBoard.model.vo.Genre;
import com.kh.common.JDBCTemplate;
import com.kh.notice.model.vo.BookClick;
import com.kh.notice.model.vo.BookCount;
import com.kh.rentBook.model.vo.BookAttachment;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

public class BookBoardDao {

	private Properties prop = new Properties();
	
	public BookBoardDao() {
		String filePath = BookBoardDao.class.getResource("/db/sql/bookBoard-mapper.xml").getPath();
	
		try {
			prop.loadFromXML(new FileInputStream(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	public ArrayList<Book> selectBookList(Connection conn, String search) {
		ArrayList<Book> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = prop.getProperty("selectBookList");
		
		
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, "%"+search+"%");
			rset=pstmt.executeQuery();
			while(rset.next()) {
				
				list.add(new Book(rset.getInt("BOOK_NO"),
								  rset.getString("GENRE_NAME"),
								  rset.getString("BOOK_TITLE"),
								  rset.getString("AUTHOR"),
								  rset.getString("BOOK_INFO"),
								  rset.getInt("RENT_COUNT"),
								  rset.getDate("CREATE_BOOK"),
								  rset.getString("STATUS"),
								  rset.getString("FILE_PATH"),
								  rset.getString("ORIGIN_NAME"),
								  rset.getString("CHANGE_NAME"),
								  rset.getInt("RNUM"))
						
						);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}

		return list;
	}

	public Book selectBook(Connection conn, int bno) {
		Book b = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = prop.getProperty("selectBook");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			rset = pstmt.executeQuery();
			if(rset.next()) {
				
				b = new Book(rset.getInt("BOOK_NO"),
								  rset.getString("GENRE_NAME"),
								  rset.getString("BOOK_TITLE"),
								  rset.getString("AUTHOR"),
								  rset.getString("BOOK_INFO"),
								  rset.getInt("RENT_COUNT"),
								  rset.getDate("CREATE_BOOK"),
								  rset.getString("STATUS"),
								  rset.getString("FILE_PATH"),
								  rset.getString("ORIGIN_NAME"),
								  rset.getString("CHANGE_NAME")
						);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		return b;
		
	}

	public ArrayList<Genre> selectCategoryList(Connection conn) {
		
		ArrayList<Genre> glist = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = prop.getProperty("selectCategoryList");
		
		try {
			pstmt=conn.prepareStatement(sql);
			rset=pstmt.executeQuery();
			
			while(rset.next()) {
				glist.add(new Genre(
						rset.getInt("GENRE_NO"),
						rset.getString("GENRE_NAME")
						));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		
		return glist;
	}

	public int insertBoard(Connection conn, Book b) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertBoard");
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			System.out.println(b);
			
			pstmt.setInt(1, Integer.parseInt(b.getGenre()));
			pstmt.setString(2, b.getBookTitle());
			pstmt.setString(3, b.getAuthor());
			pstmt.setString(4, b.getBookInfo());
			pstmt.setDate(5, b.getCreateBook());
			
			
			
			result = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		
		return result;
	}

	public int insertBoard(Connection conn, Cover c) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertCover");
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, c.getOriginName());
			pstmt.setString(2, c.getChangeName());
			pstmt.setString(3, c.getFile_path());
			
			result = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		
		return result;
	}
	
	public int insertBookAttachment(Connection conn, BookAttachment ba) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertBookAttachment");
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ba.getFilePath());
			pstmt.setString(2, ba.getOriginName());
			pstmt.setString(3, ba.getChangeName());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		
		
		return result;
	}


	public int deleteBook(Connection conn, int bno) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("deleteBook");
		try {
			pstmt= conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			result= pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
		
		
	}

	public Cover selectCover(Connection conn, int bno) {
		Cover c = null;
		ResultSet rset = null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectCover");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			rset= pstmt.executeQuery();
			
			if(rset.next()) {
				c = new Cover(
							rset.getInt("FILE_NO"),
							rset.getInt("BOOK_NO"),
							rset.getString("ORIGIN_NAME"),							
							rset.getString("CHANGE_NAME"),	
							rset.getString("FILE_PATH"),	
							rset.getDate("ENROLL_DATE"),
							rset.getString("STATUS")
						);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		
		return c;
	}

	public int updateBook(Connection conn, Book b) {
		
		int result = 0; 
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("updateBook");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, b.getBookTitle());
			pstmt.setInt(2, Integer.parseInt(b.getGenre()));
			pstmt.setString(3, b.getAuthor());
			pstmt.setDate(4, b.getCreateBook());
			pstmt.setString(5, b.getBookInfo());
			pstmt.setInt(6, b.getBookNo());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
		
	}
	
	
	public int updateBookAttachment(Connection conn, BookAttachment ba) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("updateBookAttachment");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ba.getFilePath());
			pstmt.setString(2, ba.getOriginName());
			pstmt.setString(3, ba.getChangeName());
			pstmt.setInt(4, ba.getBookNo());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		System.out.println(ba.getBookNo());
		System.out.println("@@@@"+result);
		return result;
	}
	
	

	public int updateCover(Connection conn, Cover c) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("updateCover");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, c.getOriginName());
			pstmt.setString(2, c.getChangeName());
			pstmt.setString(3, c.getFile_path());
			pstmt.setInt(4, c.getFileNo());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
		
		
	}

	public int selectListCount(Connection conn) {
		
		int listCount = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectListCount");
		
		try {
			pstmt= conn.prepareStatement(sql);
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				listCount = rset.getInt("COUNT");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		
		
		
		return listCount;
	}

	public int rentbookInsert(Connection conn, int bno, int userNo) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("rentbookInsert");
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			pstmt.setInt(2, userNo);
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		
		return result;
		
	}

	public int rentbookChk(Connection conn, int bno, int userNo) {
		int count = 0 ;
		ResultSet rset = null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("rentbookChk");
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			pstmt.setInt(2,  userNo);
			rset = pstmt.executeQuery();
			if(rset.next()) {
				count = rset.getInt("COUNT");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		
		
		return count;
	}

	public BookAttachment selectBookAttachment(Connection conn, int bno) {
		BookAttachment ba = null;
		ResultSet rset = null;		
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectBookAttachment");
		System.out.println(bno);
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			rset= pstmt.executeQuery();
			
			if(rset.next()) {
				ba = new BookAttachment(
							rset.getInt("BOOK_NO"),
							rset.getString("FILE_PATH"),
							rset.getString("ORIGIN_NAME"),
							rset.getString("CHANGE_NAME")
						);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		
		System.out.println(ba);
		return ba;
	}
	public int insertLike(Connection conn, int userNo, int bno) {
		int result=0;
		PreparedStatement pstmt = null;
		String sql=prop.getProperty("insertLike");
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,bno);
			pstmt.setInt(2, userNo);
			
			result=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
		}
		
		return result; 
		
		
	}

	public ArrayList<Book> selectLike(int userNo, Connection conn) {
		ResultSet rset=null;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("selectLike");
		ArrayList<Book> list=new ArrayList<>();
		System.out.println("dao"+userNo);
	
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userNo);
			
			rset=pstmt.executeQuery();
			
			while(rset.next()) {
				list.add(new Book(rset.getInt("BOOK_NO")
								 ,rset.getString("BOOK_TITLE")
								 ,rset.getString("AUTHOR")
								 
						));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
			JDBCTemplate.close(rset);
		}
		return list;
	}

	public int deleteLike(Connection conn, int userNo, int bno) {
		int result=0;
		PreparedStatement pstmt=null;
		String sql=prop.getProperty("deleteLike");
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userNo);
			pstmt.setInt(2, bno);
			
			result=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(pstmt);
		}
		
		return result;
	}
	
		public int increaseBookCount(Connection conn, int bno) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("increaseBookCount");

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			System.out.println(bno);

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
		
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
				
		return result;
	
	}

		public Book selectBookCount(Connection conn, int bno) {
			
			Book bc = null;
			ResultSet rset = null;
			PreparedStatement pstmt = null;
			String sql = prop.getProperty("selectBookCount");
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, bno);
				
				rset = pstmt.executeQuery();
				
				if (rset.next()) {
					bc = new Book (rset.getInt("CLICK"));
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				JDBCTemplate.close(rset);
				JDBCTemplate.close(pstmt);
			}

			return bc;
		}

		//rentCount 조회  최근30일이내 대출권수!!!!!!!
		public int rentCount(Connection conn, int bno) {
			
			
			int count = 0;
			ResultSet rset = null;
			PreparedStatement pstmt = null;
			
			String sql = prop.getProperty("rentCount");
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, bno);
				
				rset = pstmt.executeQuery();
				
				if (rset.next()) {
					count=rset.getInt("COUNT");
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				JDBCTemplate.close(rset);
				JDBCTemplate.close(pstmt);
			}

			return count;
		}

	
	
	


}
